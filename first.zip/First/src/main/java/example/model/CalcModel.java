package example.model;

public class CalcModel {
	
	
	public double calc(double x ,double y) {
		return x+y;
	}

}
